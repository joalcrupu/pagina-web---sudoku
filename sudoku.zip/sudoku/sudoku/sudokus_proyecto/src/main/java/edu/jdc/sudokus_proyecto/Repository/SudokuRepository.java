package edu.jdc.sudokus_proyecto.Repository;

import edu.jdc.sudokus_proyecto.Entity.SudokuEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SudokuRepository extends JpaRepository<SudokuEntity, Long> {
    List<SudokuEntity> findByUsuarioId(Long usuarioId);
}