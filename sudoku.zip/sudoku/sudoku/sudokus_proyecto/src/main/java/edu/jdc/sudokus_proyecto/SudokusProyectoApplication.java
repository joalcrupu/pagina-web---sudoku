package edu.jdc.sudokus_proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SudokusProyectoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SudokusProyectoApplication.class, args);
    }

}
