package edu.jdc.sudokus_proyecto.Controller;

import edu.jdc.sudokus_proyecto.Entity.UsuarioEntity;
import edu.jdc.sudokus_proyecto.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/registro")
    public String mostrarRegistro() {
        return "registro";
    }

    @PostMapping("/registro")
    public String registrarUsuario(@ModelAttribute UsuarioEntity usuario) {

        usuarioService.registrarUsuario(usuario);

        return "redirect:/login";
    }

    @GetMapping("/login")
    public String mostrarLogin() {
        return "login";
    }

}
