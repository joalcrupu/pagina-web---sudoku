package edu.jdc.sudokus_proyecto.DTO;   // ← ¡IMPORTANTE! El paquete debe ser este

public class PerfilDTO {

    private String nombre;
    private int puntaje;
    private int partidasGanadas;
    private int partidasPerdidas;

    // Constructor vacío (necesario para Jackson)
    public PerfilDTO() {
    }

    // Constructor con todos los campos (opcional)
    public PerfilDTO(String nombre, int puntaje, int partidasGanadas, int partidasPerdidas) {
        this.nombre = nombre;
        this.puntaje = puntaje;
        this.partidasGanadas = partidasGanadas;
        this.partidasPerdidas = partidasPerdidas;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(int puntaje) {
        this.puntaje = puntaje;
    }

    public int getPartidasGanadas() {
        return partidasGanadas;
    }

    public void setPartidasGanadas(int partidasGanadas) {
        this.partidasGanadas = partidasGanadas;
    }

    public int getPartidasPerdidas() {
        return partidasPerdidas;
    }

    public void setPartidasPerdidas(int partidasPerdidas) {
        this.partidasPerdidas = partidasPerdidas;
    }
}