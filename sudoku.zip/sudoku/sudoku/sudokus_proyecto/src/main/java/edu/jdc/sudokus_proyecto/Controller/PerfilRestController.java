package edu.jdc.sudokus_proyecto.Controller;

import edu.jdc.sudokus_proyecto.Entity.UsuarioEntity;
import edu.jdc.sudokus_proyecto.Service.UsuarioService;
import edu.jdc.sudokus_proyecto.DTO.PerfilDTO;  // ← OJO: DTO con mayúscula
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PerfilRestController {

    private final UsuarioService usuarioService;

    public PerfilRestController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/api/perfil")
    public PerfilDTO getPerfil(Authentication auth) {
        String correo = auth.getName();
        UsuarioEntity usuario = usuarioService.obtenerPorCorreo(correo); // ← usa este método

        PerfilDTO dto = new PerfilDTO();
        dto.setNombre(usuario.getNombre());
        dto.setPuntaje(usuario.getPuntaje());
        dto.setPartidasGanadas(usuario.getPartidasGanadas());
        dto.setPartidasPerdidas(usuario.getPartidasPerdidas());

        return dto;
    }
}