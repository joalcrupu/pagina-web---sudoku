package edu.jdc.sudokus_proyecto.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import edu.jdc.sudokus_proyecto.Entity.SudokuEntity;
import edu.jdc.sudokus_proyecto.Entity.UsuarioEntity;
import edu.jdc.sudokus_proyecto.Repository.SudokuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SudokuService {

    @Autowired
    private SudokuRepository sudokuRepository;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Valida si un número puede ir en la posición (fila, columna)
     * sin repetir en fila, columna o subcuadrante 3x3.
     */
    public boolean esNumeroValido(int[][] matriz, int fila, int columna, int numero) {
        // Validar fila
        for (int j = 0; j < 9; j++) {
            if (j != columna && matriz[fila][j] == numero) return false;
        }
        // Validar columna
        for (int i = 0; i < 9; i++) {
            if (i != fila && matriz[i][columna] == numero) return false;
        }
        // Validar subcuadrante 3x3
        int startRow = (fila / 3) * 3;
        int startCol = (columna / 3) * 3;
        for (int i = startRow; i < startRow + 3; i++) {
            for (int j = startCol; j < startCol + 3; j++) {
                if ((i != fila || j != columna) && matriz[i][j] == numero) return false;
            }
        }
        return true;
    }

    /**
     * Guarda un sudoku después de validar toda la matriz.
     */
    public SudokuEntity guardarSudoku(int[][] matriz, String dificultad, UsuarioEntity usuario) throws Exception {
        // Validar toda la matriz
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (matriz[i][j] != 0 && !esNumeroValido(matriz, i, j, matriz[i][j])) {
                    throw new Exception("Conflicto en fila " + (i+1) + ", columna " + (j+1));
                }
            }
        }
        String matrizJson = objectMapper.writeValueAsString(matriz);
        SudokuEntity sudoku = new SudokuEntity();
        sudoku.setMatriz(matrizJson);
        sudoku.setDificultad(dificultad);
        sudoku.setUsuario(usuario);
        return sudokuRepository.save(sudoku);
    }

    /**
     * Obtiene todos los sudokus de un usuario por su ID.
     */
    public List<SudokuEntity> getSudokusByUsuario(Long usuarioId) {
        return sudokuRepository.findByUsuarioId(usuarioId);
    }

    /**
     * Obtiene un sudoku por su ID.
     */
    public SudokuEntity getSudokuById(Long id) {
        return sudokuRepository.findById(id).orElse(null);
    }
}