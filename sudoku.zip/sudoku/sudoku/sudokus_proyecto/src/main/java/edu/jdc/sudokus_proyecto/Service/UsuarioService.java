package edu.jdc.sudokus_proyecto.Service;

import edu.jdc.sudokus_proyecto.Entity.UsuarioEntity;
import edu.jdc.sudokus_proyecto.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UsuarioEntity registrarUsuario(UsuarioEntity usuario) {

        usuario.setPassword(
                passwordEncoder.encode(usuario.getPassword())
        );

        return usuarioRepository.save(usuario);
    }

    public void sumarPuntaje(String correo, int puntos) {

        UsuarioEntity usuario = usuarioRepository
                .findByCorreo(correo)
                .orElseThrow();

        usuario.setPuntaje(
                usuario.getPuntaje() + puntos
        );

        usuario.setPartidasGanadas(
                usuario.getPartidasGanadas() + 1
        );

        usuarioRepository.save(usuario);
    }

    public void sumarDerrota(String correo) {

        UsuarioEntity usuario = usuarioRepository
                .findByCorreo(correo)
                .orElseThrow();

        usuario.setPartidasPerdidas(
                usuario.getPartidasPerdidas() + 1
        );

        usuarioRepository.save(usuario);
    }
    public UsuarioEntity obtenerPorCorreo(String correo) {
        return usuarioRepository.findByCorreo(correo)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }
    public UsuarioEntity findByCorreo(String correo) {
        return usuarioRepository.findByCorreo(correo)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con correo: " + correo));
    }
}
