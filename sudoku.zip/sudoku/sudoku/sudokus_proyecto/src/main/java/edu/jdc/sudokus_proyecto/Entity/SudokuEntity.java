package edu.jdc.sudokus_proyecto.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "sudokus")
public class SudokuEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String matriz; // JSON con la matriz 9x9

    private String dificultad;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private UsuarioEntity usuario;

    // Constructores
    public SudokuEntity() {}

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getMatriz() { return matriz; }
    public void setMatriz(String matriz) { this.matriz = matriz; }

    public String getDificultad() { return dificultad; }
    public void setDificultad(String dificultad) { this.dificultad = dificultad; }

    public UsuarioEntity getUsuario() { return usuario; }
    public void setUsuario(UsuarioEntity usuario) { this.usuario = usuario; }
}