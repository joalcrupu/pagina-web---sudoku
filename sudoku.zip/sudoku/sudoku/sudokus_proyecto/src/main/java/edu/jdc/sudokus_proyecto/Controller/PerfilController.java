package edu.jdc.sudokus_proyecto.Controller;

import edu.jdc.sudokus_proyecto.Entity.UsuarioEntity;
import edu.jdc.sudokus_proyecto.Repository.UsuarioRepository;
import edu.jdc.sudokus_proyecto.Service.SudokuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class PerfilController {

    private final UsuarioRepository usuarioRepository;
    private final SudokuService sudokuService;

    @Autowired
    public PerfilController(UsuarioRepository usuarioRepository, SudokuService sudokuService) {
        this.usuarioRepository = usuarioRepository;
        this.sudokuService = sudokuService;
    }

    @GetMapping("/perfil")
    public String perfil(Authentication auth, Model model) {
        if (auth == null) {
            return "redirect:/login";
        }

        UsuarioEntity usuario = usuarioRepository.findByCorreo(auth.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);

        // Obtener la lista de sudokus guardados por el usuario
        List<?> sudokus = sudokuService.getSudokusByUsuario(usuario.getId());
        model.addAttribute("sudokus", sudokus);

        return "perfil";
    }
}