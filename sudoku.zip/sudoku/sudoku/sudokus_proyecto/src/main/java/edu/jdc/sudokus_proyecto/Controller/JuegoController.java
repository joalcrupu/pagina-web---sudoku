package edu.jdc.sudokus_proyecto.Controller;

import edu.jdc.sudokus_proyecto.Service.UsuarioService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/juego")
public class JuegoController {

    private final UsuarioService usuarioService;

    public JuegoController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping("/ganar")
    public void ganar(
            Authentication auth,
            @RequestParam int puntos
    ) {

        String correo = auth.getName();

        usuarioService.sumarPuntaje(correo, puntos);
    }

    @PostMapping("/perder")
    public void perder(Authentication auth) {

        String correo = auth.getName();

        usuarioService.sumarDerrota(correo);
    }

}
