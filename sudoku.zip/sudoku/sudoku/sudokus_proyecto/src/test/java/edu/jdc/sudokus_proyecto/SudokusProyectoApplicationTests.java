package edu.jdc.sudokus_proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SudokusProyectoApplicationTests {

    @Test
    void contextLoads() {
    }

}
